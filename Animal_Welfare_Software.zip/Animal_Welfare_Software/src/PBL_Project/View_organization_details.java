
package PBL_Project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import project.Connectivity;

/**
 *
 * @author Ananya Srivastava
 */
public class View_organization_details extends javax.swing.JFrame {

    /**
     * Creates new form View_organization_details
     */
    public View_organization_details() {
        initComponents();
    }

    
     @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        SEARCH = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        OrganizationTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        Search = new javax.swing.JButton();
        SearchAll = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        SEARCH.setIcon(new javax.swing.ImageIcon("C:\\Users\\Ananya Srivastava\\FeedingAnimals.png")); // NOI18N
        getContentPane().add(SEARCH, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 280, 700, 240));

        OrganizationTable.setBackground(new java.awt.Color(255, 204, 204));
        OrganizationTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "NAME", "ESTABLISHED", "HEADED BY", "CONTACT NO.", "EMAIL", "ADDRESS"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Long.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane2.setViewportView(OrganizationTable);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 670, 120));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("VIEW ANIMAL ORGANIZATION DETAILS");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(169, 8, -1, -1));

        Search.setText("SEARCH");
        Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchActionPerformed(evt);
            }
        });
        jPanel2.add(Search, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 230, 110, 40));

        SearchAll.setText("SEARCH ALL");
        SearchAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SearchAllActionPerformed(evt);
            }
        });
        jPanel2.add(SearchAll, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 230, 110, 40));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("ENTER ID ");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 190, -1, -1));
        jPanel2.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 190, 150, -1));

        jButton1.setText("BACK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 243, 60, 30));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 700, 290));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchActionPerformed
      try
        {

            DefaultTableModel d = (DefaultTableModel) OrganizationTable.getModel();
            d.setRowCount(0);

            Connection con = Connectivity.getCon();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from organization where ID = "+Integer.parseInt(jTextField1.getText().trim()));
            if(rs.next()){
                 String Id = rs.getInt(1)+"";
                String name = rs.getString(2);
                String established = rs.getString(3)+"";
                String headedBy = rs.getString(4)+"";
                String contactNo = rs.getLong(5)+"";
                String email =rs.getString(6)+"";
                String address = rs.getString(7)+"";
                
                d.addRow(new String[]{Id,name,established,headedBy,contactNo,email,address});

            }
        }
        catch(Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this, "Error in displaying");
            System.out.println(e);

        }
    }//GEN-LAST:event_SearchActionPerformed

    private void SearchAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SearchAllActionPerformed
      try
        {

            DefaultTableModel d = (DefaultTableModel) OrganizationTable.getModel();
            d.setRowCount(0);

            Connection con = Connectivity.getCon();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from organization");
            while(rs.next()){
                String Id = rs.getInt(1)+"";
                String name = rs.getString(2);
                String established = rs.getString(3)+"";
                String headedBy = rs.getString(4)+"";
                String contactNo = rs.getLong(5)+"";
                String email =rs.getString(6)+"";
                String address = rs.getString(7)+"";

                d.addRow(new String[]{Id,name,established,headedBy,contactNo,email,address});

            }
        }
        catch(Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this, "Error in displaying");
            System.out.println(e);

        }        
    }//GEN-LAST:event_SearchAllActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        setVisible(false);
        new AdminHome().setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(View_organization_details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(View_organization_details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(View_organization_details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(View_organization_details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new View_organization_details().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable OrganizationTable;
    private javax.swing.JLabel SEARCH;
    private javax.swing.JButton Search;
    private javax.swing.JButton SearchAll;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
