package PBL_Project;
import java.awt.HeadlessException;
import project.Connectivity;
import java.sql.*;
import javax.swing.JOptionPane;
public class Update_patient_details extends javax.swing.JFrame {
    int patientId;
    String name;
    String ownerName;
    String type;
    String breed;
    String gender;
    int age;
    long contactNo;
    String address;
    String anyMajorDisease;
    String vaccinated;
    String doctorAssigned;

   
    public Update_patient_details() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        fetch = new javax.swing.JButton();
        update = new javax.swing.JButton();
        jComboBox3 = new javax.swing.JComboBox<>();
        back = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(0, 0));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("ANIMAL PATIENT ID");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 75, 140, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("NAME");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 113, 80, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setText("OWNER NAME");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 151, 130, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("ANIMAL TYPE");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 189, 130, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("BREED");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 229, 100, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setText("GENDER");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 266, 100, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("AGE");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(63, 301, 80, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("CONTACT NO.");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(493, 68, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("ADDRESS");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(493, 124, 71, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("ANY MAJOR DISEASE SUFFERED");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(493, 174, -1, -1));
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 72, 150, -1));
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 110, 150, -1));
        getContentPane().add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 148, 150, -1));
        getContentPane().add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 189, 150, -1));
        getContentPane().add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 226, 150, -1));

        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField7, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 70, 130, -1));
        getContentPane().add(jTextField8, new org.netbeans.lib.awtextra.AbsoluteConstraints(683, 116, 130, 40));
        getContentPane().add(jTextField9, new org.netbeans.lib.awtextra.AbsoluteConstraints(689, 171, 124, 38));

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        getContentPane().add(jComboBox1, new org.netbeans.lib.awtextra.AbsoluteConstraints(235, 262, 150, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("VACCINATED");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(493, 229, 130, -1));

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Yes", "No" }));
        jComboBox2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2ActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBox2, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 230, 130, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel12.setText("UPDATE PATIENT DETAILS");
        getContentPane().add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(273, 11, -1, 20));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("DOCTOR ASSIGNED");
        getContentPane().add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(493, 282, -1, -1));
        getContentPane().add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 300, 140, -1));

        fetch.setText("FETCH");
        fetch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fetchActionPerformed(evt);
            }
        });
        getContentPane().add(fetch, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 350, 90, 40));

        update.setText("UPDATE");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        getContentPane().add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 350, 110, 40));

        jComboBox3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dr. Rahul Sharma", "Dr. Shruti Singh", "Dr. Manav Goel" }));
        getContentPane().add(jComboBox3, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 280, 130, -1));

        back.setText("Back");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        getContentPane().add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 408, 71, 33));

        delete.setText("DELETE");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        getContentPane().add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 350, 110, 40));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PBL_Project/imagedogcat.jpg"))); // NOI18N
        jLabel14.setText("jLabel14");
        getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 870, 440));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void jComboBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox2ActionPerformed

    private void fetchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fetchActionPerformed
        
        try{
            patientId = Integer.parseInt(jTextField1.getText().trim());
            Connection con = Connectivity.getCon();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from Animal_Patient where PID="+patientId+"");
            if(rs.next()){
                    jTextField2.setText(rs.getString(2));
                    jTextField3.setText(rs.getString(3)+"");
                    jTextField4.setText(rs.getString(4));
                    jTextField5.setText(rs.getString(5)+"");
                    jComboBox1.setSelectedItem(rs.getString(6)+"");
                    jTextField6.setText(rs.getInt(7)+"");
                    jTextField7.setText(rs.getLong(8)+"");
                    jTextField8.setText(rs.getString(9));
                    jTextField9.setText(rs.getString(10));
                    jComboBox2.setSelectedItem(rs.getString(11));
                    jComboBox3.setSelectedItem(rs.getString(12));
                    jTextField2.setEditable(true);
                    jTextField3.setEditable(true);
                    jTextField4.setEditable(true);
                    jTextField5.setEditable(true);
                    jComboBox1.setEditable(true);
                    jTextField6.setEditable(true);
                    jTextField7.setEditable(true);
                    jTextField8.setEditable(true);
                    jTextField9.setEditable(true);
                    jComboBox1.setEditable(true);
                    jComboBox3.setEditable(true);
                    jTextField1.setEditable(false);
                    
                    
            }else{
                    javax.swing.JOptionPane.showMessageDialog(this, "Not Found!");
            }
        }catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(this, "Error in fetching details!");
            System.out.println(e);
        }

    }//GEN-LAST:event_fetchActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
    
        try{
        patientId = Integer.parseInt(jTextField1.getText());
        name = jTextField2.getText();
        ownerName = jTextField3.getText();
        type = jTextField4.getText();
        breed = jTextField5.getText();
        gender = (String)jComboBox1.getSelectedItem();
        age = Integer.parseInt(jTextField6.getText());
        contactNo = Long.parseLong(jTextField7.getText());
        address = jTextField8.getText();
        anyMajorDisease = jTextField9.getText();
        vaccinated = (String)jComboBox2.getSelectedItem();
        doctorAssigned = (String)jComboBox3.getSelectedItem();
        
         if((patientId<0 || age<0 || contactNo<0))
            {
                throw new MyException1("Negative values not allowed!!Please enter again");
            }
            
            Connection con = Connectivity.getCon();
            Statement s = con.createStatement();
            int rs = s.executeUpdate("update Animal_Patient set animalName = '"+name+"', ownerName='"+ownerName+"',animalType='"+type+"', breed='"+breed+"' ,gender='"+gender+"',age='"+age+"',contactNo = '"+contactNo+"',address = '"+address+"',anyMajorDisease = '"+anyMajorDisease+"',Vaccinated = '"+vaccinated+"',doctorAssigned = '"+doctorAssigned+"'where PID='"+patientId+"'");
            if(rs==0){
                    javax.swing.JOptionPane.showMessageDialog(this, "Not Done!");
            }else{
                    javax.swing.JOptionPane.showMessageDialog(this, "Updated!");
                    
                    jTextField1.setEditable(true);
                    jTextField2.setEditable(false);
                    jTextField3.setEditable(false);
                    jTextField4.setEditable(false);
                    jTextField5.setEditable(false);
                    jComboBox1.setEditable(false);
                    jTextField6.setEditable(false);
                    jTextField7.setEditable(false);
                    jTextField8.setEditable(false);
                    jTextField9.setEditable(false);
                    jComboBox1.setEditable(false);
                    jComboBox3.setEditable(false);
                    
                    jTextField2.setText("");
                    jTextField3.setText("");
                    jTextField4.setText("");
                    jTextField5.setText("");
                    jComboBox1.setSelectedItem("");
                    jTextField6.setText("");
                    jTextField7.setText("");
                    jTextField8.setText("");
                    jTextField9.setText("");
                    jComboBox1.setSelectedItem("");
                    jComboBox3.setSelectedItem("");
            }
        }catch(MyException1 | HeadlessException e)
        {
            JOptionPane.showMessageDialog(this,e);
        }
     
        catch(NumberFormatException e){
            
            JOptionPane.showMessageDialog(this, "Enter data in correct format!");
        }
        catch(Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this, "Error in updating!");
            javax.swing.JOptionPane.showMessageDialog(null,e);
        }

        
    }//GEN-LAST:event_updateActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        setVisible(false);
        new AdminHome().setVisible(true);
    }//GEN-LAST:event_backActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        try{
        patientId = Integer.parseInt(jTextField1.getText());
         Connection con = Connectivity.getCon();
            Statement s = con.createStatement();
            int rs = s.executeUpdate("delete from Animal_Patient where PID =" +patientId);
            if(rs==0){
                    javax.swing.JOptionPane.showMessageDialog(this, "Not Done!");
            }else{
                    javax.swing.JOptionPane.showMessageDialog(this, "Deleted!");
                    jTextField1.setText("");
                    jTextField2.setText("");
                    jTextField3.setText("");
                    jTextField4.setText("");
                    jTextField5.setText("");
                    jComboBox1.setSelectedItem("");
                    jTextField6.setText("");
                    jTextField7.setText("");
                    jTextField8.setText("");
                    jTextField9.setText("");
                    jComboBox1.setSelectedItem("");
                    jComboBox3.setSelectedItem("");
                    
            }
        }
        catch(Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this,"error in deleting");
         }
           
    }//GEN-LAST:event_deleteActionPerformed

    
    public static void main(String args[]) {
       
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Update_patient_details().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back;
    private javax.swing.JButton delete;
    private javax.swing.JButton fetch;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JComboBox<String> jComboBox3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
