package PBL_Project;
import project.Connectivity;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
public class View_patient_details extends javax.swing.JFrame {

    public View_patient_details() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        PetPatientTable = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        searchAll = new javax.swing.JButton();
        search = new javax.swing.JButton();
        back = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        Close = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocation(new java.awt.Point(0, 0));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setText("ANIMAL DETAILS");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(382, 11, 237, -1));

        PetPatientTable.setBackground(new java.awt.Color(204, 255, 255));
        PetPatientTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Patient ID", "Name", "Owner Name", "Type", "Breed", "Gender", "Age", "Contact No.", "Address", "Any major disease", "Vaccinated", "Vet Assigned"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Long.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(PetPatientTable);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 1030, 120));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PBL_Project/logo5.jpg"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 170, 324, 220));

        searchAll.setText("SEARCH ALL");
        searchAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchAllActionPerformed(evt);
            }
        });
        jPanel1.add(searchAll, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 257, 160, 50));

        search.setText("SEARCH");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        jPanel1.add(search, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 260, 100, 50));

        back.setText("BACK");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        jPanel1.add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, 70, 30));
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 200, 156, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("ENTER  ANIMAL PATIENT ID ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 210, 180, -1));

        Close.setText("Close");
        Close.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CloseActionPerformed(evt);
            }
        });
        jPanel1.add(Close, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 350, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1040, 400));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
try{
            DefaultTableModel d = (DefaultTableModel) PetPatientTable.getModel();
            d.setRowCount(0);
            
            Connection con = Connectivity.getCon();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from Animal_Patient where PID = "+Integer.parseInt(jTextField1.getText().trim()));
            if(rs.next()){
               String PatientId = rs.getInt(1)+"";
               String name = rs.getString(2);
               String ownerName = rs.getString(3)+"";
                String type = rs.getString(4);
                String breed = rs.getString(5)+"";
                String gender=rs.getString(6)+"";
                String age = rs.getString(7)+"";
                String contactNo = rs.getLong(8)+"";
                String address = rs.getString(9)+"";
                String anyMajorDisease=rs.getString(10)+"";
                String vaccinated = rs.getString(11)+"";
                String doctorAssigned = rs.getString(12)+"";
               
                
                d.addRow(new String[]{PatientId,name,ownerName,type,breed,gender,age,contactNo,address,anyMajorDisease,vaccinated,doctorAssigned});
                
            }

               
            
        }catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(this, "Error in displaying");
            System.out.println(e);
        }

    
        
    }//GEN-LAST:event_searchActionPerformed

    private void searchAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchAllActionPerformed
 
        try{
            DefaultTableModel d = (DefaultTableModel) PetPatientTable.getModel();
            d.setRowCount(0);
            
            Connection con = Connectivity.getCon();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from Animal_Patient");
           
            while(rs.next()){
               String PatientId = rs.getInt(1)+"";
               String name = rs.getString(2);
               String ownerName = rs.getString(3)+"";
                String type = rs.getString(4);
                String breed = rs.getString(5)+"";
                String gender=rs.getString(6)+"";
                String age = rs.getString(7)+"";
                String contactNo = rs.getLong(8)+"";
                String address = rs.getString(9)+"";
                String anyMajorDisease=rs.getString(10)+"";
                String vaccinated = rs.getString(11)+"";
                String doctorAssigned = rs.getString(12)+"";
               
                
                d.addRow(new String[]{PatientId,name,ownerName,type,breed,gender,age,contactNo,address,anyMajorDisease,vaccinated,doctorAssigned});
                
            }

        }catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(this, "Error in displaying");
            System.out.println(e);
        }
    
        
    }//GEN-LAST:event_searchAllActionPerformed

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        setVisible(false);
        new AdminHome().setVisible(true);
    }//GEN-LAST:event_backActionPerformed

    private void CloseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CloseActionPerformed
       new VetHome().setVisible(true);
    }//GEN-LAST:event_CloseActionPerformed

   
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new View_patient_details().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton Close;
    private javax.swing.JTable PetPatientTable;
    private javax.swing.JButton back;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton search;
    private javax.swing.JButton searchAll;
    // End of variables declaration//GEN-END:variables
}
