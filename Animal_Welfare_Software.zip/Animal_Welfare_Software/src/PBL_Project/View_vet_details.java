
package PBL_Project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;
import project.Connectivity;

public class View_vet_details extends javax.swing.JFrame {

    
    public View_vet_details() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        VeterinarianTable = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        search = new javax.swing.JButton();
        searchAll = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        BACK = new javax.swing.JButton();
        jToggleButton1 = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PBL_Project/vetlogo.jpg"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 180, 300, 230));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText(" VETERINARIAN DETAILS");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 270, -1));

        VeterinarianTable.setBackground(new java.awt.Color(204, 255, 255));
        VeterinarianTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "VET ID", "NAME", "GENDER", "AGE", "SPECIALIZATION", "CONTACT NO.", "ADDRESS"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class, java.lang.Long.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(VeterinarianTable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 60, 806, 120));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("ENTER VET ID ");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 250, 120, -1));

        search.setText("SEARCH");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });
        jPanel1.add(search, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 300, 100, 40));

        searchAll.setText("SEARCH ALL");
        searchAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchAllActionPerformed(evt);
            }
        });
        jPanel1.add(searchAll, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 300, 100, 40));
        jPanel1.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 250, 170, -1));

        BACK.setText("BACK");
        BACK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BACKActionPerformed(evt);
            }
        });
        jPanel1.add(BACK, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, -1, -1));

        jToggleButton1.setText("X");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jToggleButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 0, 40, 30));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 850, 410));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void searchAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchAllActionPerformed
        try
        {

            DefaultTableModel d = (DefaultTableModel) VeterinarianTable.getModel();
            d.setRowCount(0);

            Connection con = Connectivity.getCon();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from veterinarian");
            while(rs.next()){
                String vetId = rs.getInt(1)+"";
                String name = rs.getString(2);
                String gender = rs.getString(3)+"";
                String age = rs.getInt(4)+"";
                String specialization = rs.getString(5)+"";
                String contactNo=rs.getLong(6)+"";
                String address = rs.getString(7)+"";

                d.addRow(new String[]{vetId,name,gender,age,specialization,contactNo,address});

            }
        }
        catch(Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this, "Error in displaying");
            System.out.println(e);

        }
    }//GEN-LAST:event_searchAllActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed
        try
        {

            DefaultTableModel d = (DefaultTableModel) VeterinarianTable.getModel();
            d.setRowCount(0);

            Connection con = Connectivity.getCon();
            Statement st = con.createStatement();
            
            ResultSet rs = st.executeQuery("select * from veterinarian where vetId = "+Integer.parseInt(jTextField1.getText().trim()));
            if(rs.next()){
                String vetId = rs.getInt(1)+"";
                String name = rs.getString(2);
                String gender = rs.getString(3)+"";
                String age = rs.getInt(4)+"";
                String specialization = rs.getString(5)+"";
                String contactNo=rs.getLong(6)+"";
                String address = rs.getString(7)+"";

                d.addRow(new String[]{vetId,name,gender,age,specialization,contactNo,address});

            }
        }
        catch(Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this, "Error in displaying");
            System.out.println(e);

        }
    }//GEN-LAST:event_searchActionPerformed

    private void BACKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BACKActionPerformed
      this.setVisible(false);
      new AdminHome().setVisible(true);
    }//GEN-LAST:event_BACKActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        this.setVisible(false);
        new UserHome().setVisible(true);
    }//GEN-LAST:event_jToggleButton1ActionPerformed

   
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new View_vet_details().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BACK;
    private javax.swing.JTable VeterinarianTable;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JButton search;
    private javax.swing.JButton searchAll;
    // End of variables declaration//GEN-END:variables
}
