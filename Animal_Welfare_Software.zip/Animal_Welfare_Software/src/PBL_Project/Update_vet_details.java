package PBL_Project;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import project.Connectivity;

public class Update_vet_details extends javax.swing.JFrame {
    int vetId;
    String vetName;
    String gender;
    int age;
    String specialization;
    long contactNo;
    String address;
    

    
    public Update_vet_details() {
        initComponents();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        back = new javax.swing.JButton();
        Fetch = new javax.swing.JButton();
        Update = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        delete = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("UPDATE VETERINARIAN DETAILS");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 240, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setText("VET ID");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 64, 52, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setText("NAME");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, 34, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("SPECIALIZATION");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, 110, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("GENDER");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 140, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setText("CONTACT NO.");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("ADDRESS");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 300, -1, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setText("AGE");
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, -1, -1));

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        getContentPane().add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 60, 140, -1));
        getContentPane().add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, 140, -1));
        getContentPane().add(jTextField3, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 140, 140, -1));
        getContentPane().add(jTextField4, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 180, 140, -1));
        getContentPane().add(jTextField5, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 140, -1));
        getContentPane().add(jTextField6, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, 140, -1));

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 290, 140, 80));

        back.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        back.setText("BACK");
        back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backActionPerformed(evt);
            }
        });
        getContentPane().add(back, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 410, 80, 30));

        Fetch.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Fetch.setText("FETCH");
        Fetch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FetchActionPerformed(evt);
            }
        });
        getContentPane().add(Fetch, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 420, 80, 40));

        Update.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        Update.setText("UPDATE");
        Update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateActionPerformed(evt);
            }
        });
        getContentPane().add(Update, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 420, 80, 40));

        jPanel1.setBackground(new java.awt.Color(0, 204, 204));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 180, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 540, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 180, 540));

        delete.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        delete.setText("DELETE");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        getContentPane().add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 420, 90, 40));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/PBL_Project/vet1.jpg"))); // NOI18N
        jLabel4.setText("jLabel4");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 0, 500, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backActionPerformed
        // TODO add your handling code here:
        setVisible(false);
        new AdminHome().setVisible(true);
    }//GEN-LAST:event_backActionPerformed

    private void FetchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FetchActionPerformed
        
        try{
            vetId = Integer.parseInt(jTextField1.getText().trim());
            Connection con = Connectivity.getCon();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from veterinarian where vetId="+vetId+"");
            if(rs.next()){
                    jTextField2.setText(rs.getString(2));
                    jTextField3.setText(rs.getString(3)+"");
                    jTextField4.setText(rs.getInt(4)+"");
                    jTextField5.setText(rs.getString(5)+"");
                    jTextField6.setText(rs.getLong(6)+"");
                    jTextArea1.setText(rs.getString(7)+"");
                    
                    jTextField2.setEditable(true);
                    jTextField3.setEditable(true);
                    jTextField4.setEditable(true);
                    jTextField5.setEditable(true);
                    jTextField6.setEditable(true);
                    jTextArea1.setEditable(true);
                    jTextField1.setEditable(false);
                    
                    
            }else{
                    javax.swing.JOptionPane.showMessageDialog(this, "Not Found!");
            }
        }catch(Exception e){
            javax.swing.JOptionPane.showMessageDialog(this, "Error in fetching details!");
            System.out.println(e);
        }
       
    }//GEN-LAST:event_FetchActionPerformed

    private void UpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateActionPerformed
        
        try{
        vetId = Integer.parseInt(jTextField1.getText());
        vetName = jTextField2.getText();
        gender = jTextField3.getText();
        age= Integer.parseInt(jTextField4.getText());
        specialization = jTextField5.getText();
        contactNo = Long.parseLong(jTextField6.getText());
        address = jTextArea1.getText();
        
        
        if((vetId<0 || age<0 || contactNo<0))
            {
                throw new MyException1("Negative values not allowed!!Please enter again");
            }
        
            Connection con = Connectivity.getCon();
            Statement s = con.createStatement();
            int rs = s.executeUpdate("update veterinarian set vetId = '"+vetId+"', vetName='"+vetName+"',gender='"+gender+"', age='"+age+"' ,specialization='"+specialization+"',contactNo = '"+contactNo+"',address = '"+address+"'where vetID='"+vetId+"'");
            if(rs==0){
                    javax.swing.JOptionPane.showMessageDialog(this, "Not Done!");
            }else{
                    javax.swing.JOptionPane.showMessageDialog(this, "Updated!");
                    
                    jTextField1.setEditable(true);
                    jTextField2.setEditable(false);
                    jTextField3.setEditable(false);
                    jTextField4.setEditable(false);
                    jTextField5.setEditable(false);
                    jTextField6.setEditable(false);
                    jTextArea1.setEditable(false);
                    
                    jTextField2.setText("");
                    jTextField3.setText("");
                    jTextField4.setText("");
                    jTextField5.setText("");
                    jTextField6.setText("");
                    jTextArea1.setText("");
            }       
        }
        catch(MyException1 e)
        {
            JOptionPane.showMessageDialog(this,e);
        }
     
        catch(NumberFormatException e){
            
            JOptionPane.showMessageDialog(this, "Enter data in correct format!");
        }
        catch(Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this, "Error in updating!");
            javax.swing.JOptionPane.showMessageDialog(null,e);
        }
       
    }//GEN-LAST:event_UpdateActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        
        try{
        vetId = Integer.parseInt(jTextField1.getText());
         Connection con = Connectivity.getCon();
            Statement s = con.createStatement();
            int rs = s.executeUpdate("delete from veterinarian where vetId =" +vetId);
            if(rs==0){
                    javax.swing.JOptionPane.showMessageDialog(this, "Not Done!");
            }else{
                    javax.swing.JOptionPane.showMessageDialog(this, "Deleted!");
        }
     }
        catch(Exception e)
        {
            javax.swing.JOptionPane.showMessageDialog(this,"error in deleting");
         }
    }//GEN-LAST:event_deleteActionPerformed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Update_vet_details().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Fetch;
    private javax.swing.JButton Update;
    private javax.swing.JButton back;
    private javax.swing.JButton delete;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    // End of variables declaration//GEN-END:variables
}
