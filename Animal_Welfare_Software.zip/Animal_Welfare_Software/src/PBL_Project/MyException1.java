
package PBL_Project;
public class MyException1 extends Exception
            {
                String str;
                
                MyException1(String str)
                {
                    this.str=str;
                }
                public String toString()
                {
                    return ("message:"+str);
                    
                }
                
            }
