
package PBL_Project;
public class Stray {
    int id;
    String name;
    int age;
    String status;
    String vac;
    String dis;
    public Stray(int animal_id,String n,int a,String vaccinated, String disease,String s){
        this.id=animal_id;
        this.name=n;
        this.age=a;
        this.vac=vaccinated;
        this.dis=disease;
        this.status=s;
    }
}
